package com.mycompany.dibujo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author B12
 */
public class principal {
    public static void main(String args[]){
        Reloj r1 = new Reloj(12.30,"pila","2024","rolex","negro");
        Helado h1= new Helado(7.6,"limon","cremoso","mediano","grande");
        Computador c1= new Computador("asus","2023","negro","portatil","grande");
        System.out.println(r1.getModelo());
        System.out.println(h1.getColor());
        System.out.println(c1.getMarca());
        r1.apagar();
    }
}
