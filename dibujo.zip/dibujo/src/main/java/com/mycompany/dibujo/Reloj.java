/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dibujo;

/**
 *
 * @author B12
 */
public class Reloj {
    double hora; 
    String tipoBateria,modelo,marca,color;
    

    public Reloj(double hora,String tipoBateria,String modelo,String marca,String color){
    this.color=color;
    this.hora=hora;
    this.marca=marca;
    this.modelo=modelo;
    this.tipoBateria=tipoBateria;
    }
 
    public String getMarca(){
        return marca;
    }
    public String getModelo(){
        return modelo;
    }
        public String getColor(){
        return color;
    }
            public String getTipoBateria(){
        return tipoBateria;
    }
                public double getHora(){
        return hora;
    }
                
    public void setMarca(String n){
        marca= n;
    }
    public void setModelo(String n){
        modelo= n;
    }
    public void setColor(String n){
        color= n;
    }
     public void setHora(double n){
        hora= n;
    }
    public void setTipoBateria(String n){
        tipoBateria= n;
    }
    
    public void cambiarHora(Double n){
       hora=n;
       System.out.println("La nueva hora es "+hora);
    }
    public void reiniciarHora(){
       hora=0;
       System.out.println("La nueva hora es "+hora);
    }
    public void cambiarBateria(){
   
       System.out.println("La bateria ya esta cambiada");
    }
    public void cambiarColor(String n){
       color=n;
       System.out.println("El nuevo color es "+color);
    }
    public void apagar(){
       hora=0;
       System.out.println("El reloj esta apagado");
    }
    
    
            
}
