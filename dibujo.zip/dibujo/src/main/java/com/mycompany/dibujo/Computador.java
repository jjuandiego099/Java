package com.mycompany.dibujo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author B12
 */
public class Computador{
    
    String marca, modelo, color, tipo, tamaño;
 

    public Computador(String marca, String modelo, String color, String tipo, String tamaño) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.tipo = tipo;
        this.tamaño = tamaño;
        // Inicialmente apagado
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public String getTipo() {
        return tipo;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setMarca(String n) {
        marca = n;
    }

    public void setModelo(String n) {
        modelo = n;
    }

    public void setColor(String n) {
        color = n;
        System.out.println("El nuevo color es " + color);
    }

    public void setTamaño(String n) {
        tamaño = n;
    }

    public void setTipo(String n) {
        tipo = n;
    }

    public void encender() {
        
        System.out.println("El computador está encendido.");
    }

    public void apagar() {
       
        System.out.println("El computador está apagado.");
    }

    public void reiniciar() {
        System.out.println("Reiniciando el computador...");
    }

    public void cambiarColor(String n) {
        setColor(n);
    }

    public void mostrarEspecificaciones() {
        System.out.println("Especificaciones del computador:");
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Color: " + color);
        System.out.println("Tipo: " + tipo);
        System.out.println("Tamaño: " + tamaño);
    }

    public void actualizarModelo(String nuevoModelo) {
        modelo = nuevoModelo;
        System.out.println("El modelo ha sido actualizado a " + modelo);
    }
}
