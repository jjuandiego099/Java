/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dibujo;

/**
 *
 * @author B12
 */
public class Helado {
    double precio; 
    String sabor,color,textura,tamaño;
    

    public Helado(double precio,String sabor,String textura,String tamaño,String color){
    this.color=color;
    this.precio=precio;
    this.sabor=sabor;
    this.tamaño=tamaño;
    this.textura=textura;
    }
    public Helado(){}
    public String getSabor(){
        return sabor;
    }
    public String getColor(){
        return color;
    }
        public String getTextura(){
        return textura;
    }
            public String getTamaño(){
        return tamaño;
    }
    public double getPrecio(){
        return precio;
    }
                
    public void setTamaño(String n){
        tamaño= n;
    }
    public void setTextura(String n){
        textura= n;
    }
    public void setColor(String n){
        color= n;
    }
     public void setSabor(String n){
        sabor= n;
    }
    public void setPrecio(double n){
        precio= n;
    }
    
    public void cambiarSabor(String n){
       sabor=n;
       System.out.println("El nuevo sabor es "+sabor);
    }
    public void derretirse(){
       System.out.println("El helado se esta derritiendo");
    }
    public void cambiarTamaño(String n){
        tamaño=n;
       System.out.println("El nuevo tamaño es "+tamaño);
    }
    public void caerse(){
       System.out.println("El helado se cayo al piso");
    }
    public void danarse(){

       System.out.println("El helado se daño y no se puede comer");
    }
    
    
            
}
